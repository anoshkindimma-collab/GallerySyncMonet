package com.givemefive.pics

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.givemefive.pics.ui.theme.MonetGalleryTheme
import com.givemefive.pics.wearable.ImageSyncManager
import com.givemefive.pics.wearable.SyncProgress
import com.givemefive.pics.wearable.WearableNode
import com.givemefive.pics.wearable.XmsWearableClient
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MonetGalleryTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    GallerySyncScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GallerySyncScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val xmsClient = remember { XmsWearableClient(context.applicationContext) }
    val syncManager = remember { ImageSyncManager(context.applicationContext, xmsClient) }

    var connectedNode by remember { mutableStateOf<WearableNode?>(null) }
    var connectionStatus by remember { mutableStateOf("Поиск браслета через Mi Fitness...") }
    var isSearching by remember { mutableStateOf(true) }

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var jpegQuality by remember { mutableFloatStateOf(85f) }
    var syncProgress by remember { mutableStateOf(SyncProgress()) }

    fun refreshConnection() {
        scope.launch {
            isSearching = true
            connectionStatus = "Подключение к Mi Fitness..."
            val res = xmsClient.getConnectedNodes()
            res.onSuccess { nodes ->
                val node = nodes.firstOrNull()
                connectedNode = node
                if (node != null) {
                    connectionStatus = "Подключено • RPK готов к приёму"
                    xmsClient.requestDeviceManagerPermission(node.id)
                } else {
                    connectionStatus = "Браслет не найден. Открой Mi Fitness в фоне"
                }
            }.onFailure { err ->
                connectedNode = null
                connectionStatus = err.message ?: "Ошибка XMS сервиса"
            }
            isSearching = false
        }
    }

    LaunchedEffect(Unit) {
        refreshConnection()
    }

    DisposableEffect(Unit) {
        onDispose {
            xmsClient.unbind()
        }
    }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            selectedUri = uri
            syncProgress = SyncProgress()
        }
    }

    Scaffold(
        topBar = {
            LargeTopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Gallery Sync",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Mi Band 11 • Material You",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { refreshConnection() }) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Обновить"
                        )
                    }
                },
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Device Status Card (Monet Surface Container)
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = if (connectedNode != null)
                        MaterialTheme.colorScheme.primaryContainer
                    else
                        MaterialTheme.colorScheme.surfaceContainerHigh
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(
                                if (connectedNode != null)
                                    MaterialTheme.colorScheme.primary
                                else
                                    MaterialTheme.colorScheme.secondaryContainer
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Watch,
                            contentDescription = null,
                            tint = if (connectedNode != null)
                                MaterialTheme.colorScheme.onPrimary
                            else
                                MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = connectedNode?.name ?: "Устройство не подключено",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = if (connectedNode != null)
                                MaterialTheme.colorScheme.onPrimaryContainer
                            else
                                MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = connectionStatus,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (connectedNode != null)
                                MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                            else
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (isSearching) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp
                        )
                    }
                }
            }

            // 2. Photo Picker Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PhotoLibrary,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (selectedUri != null) "Фото выбрано" else "Выбор изображения",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = selectedUri?.lastPathSegment ?: "Поддерживаются JPG, PNG, WEBP",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    FilledTonalButton(
                        onClick = {
                            photoPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(18.dp),
                        enabled = !syncProgress.isSyncing
                    ) {
                        Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (selectedUri == null) "Выбрать фото из галереи" else "Выбрать другое фото",
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Compression quality slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Качество сжатия JPEG",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${jpegQuality.toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = jpegQuality,
                            onValueChange = { jpegQuality = it },
                            valueRange = 50f..95f,
                            enabled = !syncProgress.isSyncing
                        )
                    }
                }
            }

            // 3. Progress / Status Card
            AnimatedVisibility(visible = syncProgress.isSyncing || syncProgress.done || syncProgress.error != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            syncProgress.error != null -> MaterialTheme.colorScheme.errorContainer
                            syncProgress.done -> MaterialTheme.colorScheme.secondaryContainer
                            else -> MaterialTheme.colorScheme.surfaceContainerHigh
                        }
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = syncProgress.error ?: syncProgress.stage,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                color = if (syncProgress.error != null)
                                    MaterialTheme.colorScheme.onErrorContainer
                                else
                                    MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                            if (syncProgress.isSyncing || syncProgress.done) {
                                Text(
                                    text = "${syncProgress.percent}%",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        if (syncProgress.isSyncing) {
                            LinearProgressIndicator(
                                progress = { syncProgress.percent / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(CircleShape)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // 4. Primary Send Action Button
            Button(
                onClick = {
                    val node = connectedNode
                    val uri = selectedUri
                    if (node != null && uri != null) {
                        scope.launch {
                            syncManager.pushImageToWatch(
                                nodeId = node.id,
                                imageUri = uri,
                                quality = jpegQuality.toInt(),
                                onProgress = { syncProgress = it }
                            )
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                shape = RoundedCornerShape(22.dp),
                enabled = connectedNode != null && selectedUri != null && !syncProgress.isSyncing
            ) {
                Icon(Icons.Rounded.SendToMobile, contentDescription = null)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (syncProgress.isSyncing) "Синхронизация..." else "Отправить на Mi Band 11",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
