package com.givemefive.pics.wearable

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class SyncProgress(
    val isSyncing: Boolean = false,
    val stage: String = "",
    val percent: Int = 0,
    val error: String? = null,
    val done: Boolean = false
)

class ImageSyncManager(
    private val context: Context,
    private val client: XmsWearableClient
) {
    companion object {
        // Chunk size in HEX characters (4000 hex chars = 2000 binary bytes per interconnect message, safe for Mi Band 11)
        private const val HEX_CHUNK_SIZE = 4000
    }

    suspend fun pushImageToWatch(
        nodeId: String,
        imageUri: Uri,
        quality: Int = 85,
        maxSide: Int = 520,
        onProgress: (SyncProgress) -> Unit
    ) = withContext(Dispatchers.IO) {
        try {
            onProgress(SyncProgress(isSyncing = true, stage = "Подготовка изображения...", percent = 0))

            val inputStream = context.contentResolver.openInputStream(imageUri)
                ?: throw IllegalStateException("Не удалось открыть выбранное фото")
            val origBitmap = inputStream.use { BitmapFactory.decodeStream(it) }
                ?: throw IllegalStateException("Не удалось декодировать изображение")

            // 1. Scale main image proportionally so longest side <= maxSide (default 520px for Mi Band 11)
            val mainScale = min(1f, maxSide.toFloat() / max(origBitmap.width, origBitmap.height))
            val mainW = max(1, (origBitmap.width * mainScale).roundToInt())
            val mainH = max(1, (origBitmap.height * mainScale).roundToInt())
            val mainBmp = Bitmap.createScaledBitmap(origBitmap, mainW, mainH, true)

            val mainOut = ByteArrayOutputStream()
            mainBmp.compress(Bitmap.CompressFormat.JPEG, quality, mainOut)
            val mainHex = bytesToHex(mainOut.toByteArray())

            // 2. Scale square/fit preview (206x206)
            val prewScale = 206f / max(origBitmap.width, origBitmap.height)
            val prewW = max(1, (origBitmap.width * prewScale).roundToInt())
            val prewH = max(1, (origBitmap.height * prewScale).roundToInt())
            val prewBmp = Bitmap.createScaledBitmap(origBitmap, prewW, prewH, true)

            val prewOut = ByteArrayOutputStream()
            prewBmp.compress(Bitmap.CompressFormat.JPEG, 75, prewOut)
            val prewHex = bytesToHex(prewOut.toByteArray())

            val fileName = "pic_${System.currentTimeMillis()}.jpg"

            // Try to wake up /pages/push on the band (ignore return value — works even if user opened app manually!)
            onProgress(SyncProgress(isSyncing = true, stage = "Открытие приёмщика на браслете...", percent = 2))
            client.launchWearPage(nodeId, "/pages/push")
            delay(600L)

            // 3. Send Main Image
            val mainOk = sendHexFile(
                nodeId = nodeId,
                aimDir = "internal://files/pics/",
                fileName = fileName,
                hexPayload = mainHex,
                stageLabel = "Отправка фото",
                basePct = 5,
                spanPct = 75,
                onProgress = onProgress
            )
            if (!mainOk) {
                throw IllegalStateException("Браслет не ответил. Открой галерею на Mi Band 11 и повтори.")
            }

            delay(350L)

            // 4. Send Preview Image
            val prewOk = sendHexFile(
                nodeId = nodeId,
                aimDir = "internal://files/pics/prew/",
                fileName = fileName,
                hexPayload = prewHex,
                stageLabel = "Отправка превью",
                basePct = 80,
                spanPct = 20,
                onProgress = onProgress
            )
            if (!prewOk) {
                throw IllegalStateException("Ошибка при передаче превью")
            }

            onProgress(SyncProgress(isSyncing = false, stage = "Готово! Фото на браслете", percent = 100, done = true))
        } catch (e: Exception) {
            onProgress(
                SyncProgress(
                    isSyncing = false,
                    stage = "Ошибка",
                    percent = 0,
                    error = e.message ?: "Неизвестная ошибка передачи"
                )
            )
        }
    }

    private suspend fun sendHexFile(
        nodeId: String,
        aimDir: String,
        fileName: String,
        hexPayload: String,
        stageLabel: String,
        basePct: Int,
        spanPct: Int,
        onProgress: (SyncProgress) -> Unit
    ): Boolean {
        val totalPacks = max(1, ceil(hexPayload.length.toDouble() / HEX_CHUNK_SIZE).toInt())
        var ackDeferred = CompletableDeferred<String>()

        client.addMessageListener(nodeId) { _, bytes ->
            val raw = String(bytes, Charsets.UTF_8)
            try {
                val obj = JSONObject(raw)
                val cmd = obj.optString("c", "")
                if (cmd.isNotEmpty() && !ackDeferred.isCompleted) {
                    ackDeferred.complete(cmd)
                }
            } catch (_: Exception) {}
        }

        // Send "start" handshake (retry up to 3 times if watch page was still opening)
        val startJson = JSONObject().apply {
            put("c", "start")
            put("d", aimDir)
            put("f", fileName)
            put("n", totalPacks)
        }.toString()

        var ready = false
        for (attempt in 1..3) {
            ackDeferred = CompletableDeferred()
            val sent = client.sendMessage(nodeId, startJson.toByteArray(Charsets.UTF_8))
            if (sent) {
                val resp = withTimeoutOrNull(2500L) { ackDeferred.await() }
                if (resp == "ready") {
                    ready = true
                    break
                }
            }
            delay(500L)
        }
        if (!ready) return false

        // Send chunks sequentially
        for (i in 0 until totalPacks) {
            val startIdx = i * HEX_CHUNK_SIZE
            val endIdx = min(hexPayload.length, startIdx + HEX_CHUNK_SIZE)
            val subHex = hexPayload.substring(startIdx, endIdx)

            val chunkJson = JSONObject().apply {
                put("c", "d")
                put("d", subHex)
                put("n", i)
            }.toString()

            val ok = client.sendMessage(nodeId, chunkJson.toByteArray(Charsets.UTF_8))
            if (!ok) return false

            val currentPct = basePct + (((i + 1).toFloat() / totalPacks) * spanPct).roundToInt()
            onProgress(
                SyncProgress(
                    isSyncing = true,
                    stage = "$stageLabel (${i + 1}/$totalPacks)",
                    percent = min(99, currentPct)
                )
            )
            // Small pacing delay so Mi Band 11 BLE buffer never overflows
            delay(35L)
        }

        // Send "end"
        val endJson = JSONObject().apply {
            put("c", "end")
        }.toString()
        client.sendMessage(nodeId, endJson.toByteArray(Charsets.UTF_8))
        return true
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val hexChars = "0123456789abcdef"
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            sb.append(hexChars[v ushr 4])
            sb.append(hexChars[v and 0x0F])
        }
        return sb.toString()
    }
}
