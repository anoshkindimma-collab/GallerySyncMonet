package com.givemefive.pics.wearable

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Binder
import android.os.IBinder
import android.os.Parcel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

data class WearableNode(
    val id: String,
    val name: String
)

class XmsWearableClient(private val context: Context) {

    companion object {
        private const val SERVICE_ACTION = "com.xiaomi.wearable.XMS_WEARABLE_SERVICE"
        private const val PKG_MI_HEALTH = "com.mi.health"
        private const val PKG_WEARABLE = "com.xiaomi.wearable"

        private const val DESC_WEARABLE = "com.xiaomi.xms.wearable.IWearableInterface"
        private const val DESC_NODE_CB = "com.xiaomi.xms.wearable.node.INodeCallback"
        private const val DESC_MSG_CB = "com.xiaomi.xms.wearable.message.IMessageCallback"
        private const val DESC_MSG_LISTENER = "com.xiaomi.xms.wearable.message.IMessageListener"
        private const val DESC_LAUNCH_CB = "com.xiaomi.xms.wearable.node.IWearAppLaunchedCallback"
        private const val DESC_PERM_CB = "com.xiaomi.xms.wearable.auth.IPermissionCallback"

        private const val TX_GET_CONNECTED_NODES = 3
        private const val TX_SEND_MESSAGE = 4
        private const val TX_ADD_MSG_LISTENER = 5
        private const val TX_REMOVE_MSG_LISTENER = 6
        private const val TX_LAUNCH_WEAR_APP = 7
        private const val TX_REQUEST_PERMISSION = 11
    }

    private var remoteBinder: IBinder? = null
    private var isBound = false
    private var onMessageCallback: ((String, ByteArray) -> Unit)? = null

    private val messageListenerBinder = object : Binder() {
        override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
            if (code == 1) {
                data.enforceInterface(DESC_MSG_LISTENER)
                val nodeId = data.readString() ?: ""
                val payload = data.createByteArray() ?: ByteArray(0)
                onMessageCallback?.invoke(nodeId, payload)
                reply?.writeNoException()
                return true
            }
            return super.onTransact(code, data, reply, flags)
        }
    }

    private var connectDeferred: CompletableDeferred<Boolean>? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            remoteBinder = service
            connectDeferred?.complete(service != null)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            remoteBinder = null
            isBound = false
        }

        override fun onBindingDied(name: ComponentName?) {
            remoteBinder = null
            isBound = false
        }
    }

    suspend fun ensureConnected(): Boolean {
        if (remoteBinder != null && remoteBinder?.isBinderAlive == true) return true
        val deferred = CompletableDeferred<Boolean>()
        connectDeferred = deferred

        val pm = context.packageManager
        val intent = Intent(SERVICE_ACTION).apply {
            setPackage(PKG_MI_HEALTH)
        }
        val targetPkg = if (pm.resolveService(intent, 0) != null) PKG_MI_HEALTH else PKG_WEARABLE
        intent.setPackage(targetPkg)

        try {
            isBound = context.bindService(intent, connection, Context.BIND_AUTO_CREATE)
            if (!isBound) return false
        } catch (_: Exception) {
            return false
        }
        return withTimeoutOrNull(4000L) { deferred.await() } ?: false
    }

    suspend fun getConnectedNodes(): Result<List<WearableNode>> {
        if (!ensureConnected()) {
            return Result.failure(IllegalStateException("Не удалось подключиться к Mi Fitness (XMS)"))
        }
        val binder = remoteBinder ?: return Result.failure(IllegalStateException("Сервис недоступен"))
        val resultDeferred = CompletableDeferred<Result<List<WearableNode>>>()

        val nodeCb = object : Binder() {
            override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
                when (code) {
                    1 -> {
                        // onNodesConnected(List<Node>)
                        data.enforceInterface(DESC_NODE_CB)
                        val count = data.readInt()
                        val list = mutableListOf<WearableNode>()
                        for (i in 0 until count) {
                            if (data.readInt() != 0) {
                                val id = data.readString() ?: ""
                                val name = data.readString() ?: "Mi Band"
                                list.add(WearableNode(id, name))
                            }
                        }
                        resultDeferred.complete(Result.success(list))
                        reply?.writeNoException()
                        return true
                    }
                    2 -> {
                        // onFailure(Status)
                        data.enforceInterface(DESC_NODE_CB)
                        val statusCode = if (data.readInt() != 0) data.readInt() else -1
                        resultDeferred.complete(Result.failure(RuntimeException("XMS Node error: $statusCode")))
                        reply?.writeNoException()
                        return true
                    }
                }
                return super.onTransact(code, data, reply, flags)
            }
        }

        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(DESC_WEARABLE)
            data.writeStrongBinder(nodeCb)
            binder.transact(TX_GET_CONNECTED_NODES, data, reply, 0)
            reply.readException()
        } catch (e: Exception) {
            return Result.failure(e)
        } finally {
            data.recycle()
            reply.recycle()
        }

        return withTimeoutOrNull(5000L) { resultDeferred.await() }
            ?: Result.failure(RuntimeException("Таймаут поиска браслета"))
    }

    suspend fun requestDeviceManagerPermission(nodeId: String): Boolean {
        val binder = remoteBinder ?: return false
        val deferred = CompletableDeferred<Boolean>()
        val permCb = object : Binder() {
            override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
                if (code == 1 || code == 2) {
                    deferred.complete(code == 1)
                    reply?.writeNoException()
                    return true
                }
                return super.onTransact(code, data, reply, flags)
            }
        }
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(DESC_WEARABLE)
            data.writeString(nodeId)
            data.writeInt(1) // 1 permission
            data.writeInt(1) // non-null Parcelable
            data.writeString("device_manager")
            data.writeStrongBinder(permCb)
            binder.transact(TX_REQUEST_PERMISSION, data, reply, 0)
            reply.readException()
        } catch (_: Exception) {
            return false
        } finally {
            data.recycle()
            reply.recycle()
        }
        return withTimeoutOrNull(4000L) { deferred.await() } ?: true
    }

    suspend fun addMessageListener(nodeId: String, listener: (String, ByteArray) -> Unit): Boolean {
        onMessageCallback = listener
        val binder = remoteBinder ?: return false
        val deferred = CompletableDeferred<Boolean>()
        val msgCb = object : Binder() {
            override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
                if (code == 1) {
                    data.enforceInterface(DESC_MSG_CB)
                    val statusCode = if (data.readInt() != 0) data.readInt() else -1
                    deferred.complete(statusCode == 0)
                    reply?.writeNoException()
                    return true
                }
                return super.onTransact(code, data, reply, flags)
            }
        }
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(DESC_WEARABLE)
            data.writeString(nodeId)
            data.writeStrongBinder(messageListenerBinder)
            data.writeStrongBinder(msgCb)
            binder.transact(TX_ADD_MSG_LISTENER, data, reply, 0)
            reply.readException()
        } catch (_: Exception) {
            return false
        } finally {
            data.recycle()
            reply.recycle()
        }
        return withTimeoutOrNull(3000L) { deferred.await() } ?: false
    }

    suspend fun launchWearPage(nodeId: String, pagePath: String): Boolean {
        val binder = remoteBinder ?: return false
        val deferred = CompletableDeferred<Boolean>()
        val launchCb = object : Binder() {
            override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
                if (code == 1) {
                    data.enforceInterface(DESC_LAUNCH_CB)
                    val statusCode = if (data.readInt() != 0) data.readInt() else -1
                    deferred.complete(statusCode == 0)
                    reply?.writeNoException()
                    return true
                }
                return super.onTransact(code, data, reply, flags)
            }
        }
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(DESC_WEARABLE)
            data.writeString(nodeId)
            data.writeString(pagePath)
            data.writeStrongBinder(launchCb)
            binder.transact(TX_LAUNCH_WEAR_APP, data, reply, 0)
            reply.readException()
        } catch (_: Exception) {
            return false
        } finally {
            data.recycle()
            reply.recycle()
        }
        return withTimeoutOrNull(3000L) { deferred.await() } ?: false
    }

    suspend fun sendMessage(nodeId: String, bytes: ByteArray): Boolean {
        val binder = remoteBinder ?: return false
        val deferred = CompletableDeferred<Boolean>()
        val msgCb = object : Binder() {
            override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
                if (code == 1) {
                    data.enforceInterface(DESC_MSG_CB)
                    val statusCode = if (data.readInt() != 0) data.readInt() else -1
                    deferred.complete(statusCode == 0)
                    reply?.writeNoException()
                    return true
                }
                return super.onTransact(code, data, reply, flags)
            }
        }
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(DESC_WEARABLE)
            data.writeString(nodeId)
            data.writeByteArray(bytes)
            data.writeStrongBinder(msgCb)
            binder.transact(TX_SEND_MESSAGE, data, reply, 0)
            reply.readException()
        } catch (_: Exception) {
            return false
        } finally {
            data.recycle()
            reply.recycle()
        }
        return withTimeoutOrNull(5000L) { deferred.await() } ?: false
    }

    fun unbind() {
        if (isBound) {
            try {
                context.unbindService(connection)
            } catch (_: Exception) {}
            isBound = false
        }
    }
}
