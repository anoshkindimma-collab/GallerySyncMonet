package com.belugich.band11.picsync

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.min

object ImageProcessor {
    private const val MAX_W = 204
    private const val MAX_H = 350
    private const val MAX_BYTES = 45 * 1024

    data class PreparedPhoto(
        val file: File,
        val fileName: String,
        val width: Int,
        val height: Int,
        val sizeBytes: Int
    )

    fun prepare(context: Context, uri: Uri): PreparedPhoto {
        val raw = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Не удалось открыть файл")

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(raw, 0, raw.size, bounds)

        var sample = 1
        while (bounds.outWidth / sample > MAX_W * 2 || bounds.outHeight / sample > MAX_H * 2) {
            sample *= 2
        }

        val decoded = BitmapFactory.decodeByteArray(
            raw, 0, raw.size, BitmapFactory.Options().apply { inSampleSize = sample }
        ) ?: throw IllegalStateException("Ошибка декодирования изображения")

        val ratio = min(
            MAX_W.toFloat() / decoded.width.toFloat(),
            MAX_H.toFloat() / decoded.height.toFloat()
        ).coerceAtMost(1.0f)

        val tw = (decoded.width * ratio).toInt().coerceAtLeast(1)
        val th = (decoded.height * ratio).toInt().coerceAtLeast(1)

        val scaled = if (tw != decoded.width || th != decoded.height) {
            Bitmap.createScaledBitmap(decoded, tw, th, true).also {
                if (it !== decoded) decoded.recycle()
            }
        } else {
            decoded
        }

        var quality = 85
        var jpegBytes: ByteArray
        do {
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, quality, out)
            jpegBytes = out.toByteArray()
            quality -= 10
        } while (jpegBytes.size > MAX_BYTES && quality >= 35)

        val dir = File(context.cacheDir, "mb11_out").apply { mkdirs() }
        val fname = "pic_${System.currentTimeMillis()}.jpg"
        val outFile = File(dir, fname)
        FileOutputStream(outFile).use { it.write(jpegBytes) }

        val w = scaled.width
        val h = scaled.height
        scaled.recycle()

        return PreparedPhoto(outFile, fname, w, h, jpegBytes.size)
    }
}
