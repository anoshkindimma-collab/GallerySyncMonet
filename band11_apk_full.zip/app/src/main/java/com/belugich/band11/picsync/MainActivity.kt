package com.belugich.band11.picsync

import android.Manifest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Color(0xFF000000),
                    surface = Color(0xFF121212),
                    primary = Color(0xFFFFFFFF),
                    onPrimary = Color(0xFF000000),
                    onBackground = Color(0xFFFFFFFF),
                    onSurface = Color(0xFFE0E0E0)
                )
            ) {
                SyncUi()
            }
        }
    }
}

@Composable
fun SyncUi() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Выбери картинку") }
    var log by remember { mutableStateOf("Ожидание...") }
    var busy by remember { mutableStateOf(false) }

    val permReq = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {}

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permReq.launch(
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
                )
            )
        }
    }

    val pickImage = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            pickedUri = uri
            status = "Выбрано: ${uri.lastPathSegment ?: "изображение"}"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(14.dp))
        Text("PicSync MB11", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Синхронизатор • Mi Band 11", fontSize = 14.sp, color = Color(0xFF9E9E9E))

        Spacer(Modifier.height(22.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFF141414)
        ) {
            Text(
                text = status,
                fontSize = 15.sp,
                color = Color.White,
                modifier = Modifier.padding(16.dp)
            )
        }

        Spacer(Modifier.height(14.dp))

        Button(
            onClick = { pickImage.launch("image/*") },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF222222),
                contentColor = Color.White
            )
        ) {
            Text("Выбрать фото", fontSize = 16.sp)
        }

        Spacer(Modifier.height(10.dp))

        Button(
            enabled = pickedUri != null && !busy,
            onClick = {
                val target = pickedUri ?: return@Button
                scope.launch {
                    busy = true
                    status = "Подготовка и отправка..."
                    try {
                        val prep = ImageProcessor.prepare(ctx, target)
                        status = "${prep.width}×${prep.height}, ${prep.sizeBytes / 1024} КБ"
                        val res = WearableBridge.sendPhoto(ctx, prep.file, prep.fileName)
                        log = res.log
                    } catch (e: Exception) {
                        status = "Ошибка"
                        log = "${e.javaClass.simpleName}: ${e.message}"
                    } finally {
                        busy = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color.Black
            )
        ) {
            Text(if (busy) "Отправка..." else "Отправить на браслет", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.height(18.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFF101010)
        ) {
            Text(
                text = log,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFFD4D4D4),
                modifier = Modifier.padding(14.dp)
            )
        }
    }
}
