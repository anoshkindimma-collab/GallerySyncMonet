package com.belugich.band11.picsync

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.File
import java.lang.reflect.Proxy

object WearableBridge {
    private const val TAG = "PicSyncMB11"
    private const val CHUNK_SIZE = 1024

    data class SendResult(
        val ok: Boolean,
        val log: String
    )

    suspend fun sendPhoto(context: Context, file: File, fileName: String): SendResult =
        withContext(Dispatchers.IO) {
            val log = StringBuilder()
            val appCtx = context.applicationContext
            val bytes = file.readBytes()
            log.appendLine("Файл: $fileName (${bytes.size} Б)")

            try {
                val wearableCls = Class.forName("com.xiaomi.xms.wearable.Wearable")
                val nodeApi = wearableCls.getMethod("getNodeApi", Context::class.java).invoke(null, appCtx)
                val msgApi = wearableCls.getMethod("getMessageApi", Context::class.java).invoke(null, appCtx)

                try {
                    val authApi = wearableCls.getMethod("getAuthApi", Context::class.java).invoke(null, appCtx)
                    val permCls = Class.forName("com.xiaomi.xms.wearable.auth.Permission")
                    val devMgr = permCls.getField("DEVICE_MANAGER").get(null)
                    val arr = java.lang.reflect.Array.newInstance(permCls, 1)
                    java.lang.reflect.Array.set(arr, 0, devMgr)
                    val req = authApi.javaClass.methods.firstOrNull { it.name == "requestPermission" }
                    if (req != null) {
                        awaitTask<Any?>(req.invoke(authApi, arr))
                    }
                } catch (_: Throwable) {
                }

                val nodes = awaitTask<List<*>>(
                    nodeApi.javaClass.getMethod("getConnectedNodes").invoke(nodeApi)
                ).orEmpty()

                if (nodes.isEmpty()) {
                    return@withContext SendResult(false, log.appendLine("Mi Band 11 не найден в connectedNodes").toString().trim())
                }

                val node = nodes.first()!!
                val nodeId = node.javaClass.getMethod("getId").invoke(node) as String
                val nodeName = node.javaClass.getMethod("getName").invoke(node)?.toString() ?: nodeId
                log.appendLine("Устройство: $nodeName ($nodeId)")

                var readyDeferred = CompletableDeferred<Boolean>()
                val listenerCls = Class.forName("com.xiaomi.xms.wearable.message.OnMessageReceivedListener")
                val proxy = Proxy.newProxyInstance(listenerCls.classLoader, arrayOf(listenerCls)) { _, m, args ->
                    if (m.name == "onMessageReceived" && args != null && args.size >= 2) {
                        val txt = (args[1] as? ByteArray)?.toString(Charsets.UTF_8).orEmpty()
                        if (txt.contains(""ready"")) {
                            readyDeferred.complete(true)
                        }
                    }
                    null
                }
                val addListener = msgApi.javaClass.methods.first {
                    it.name == "addListener" && it.parameterTypes.size == 2
                }
                awaitTask<Any?>(addListener.invoke(msgApi, nodeId, proxy))

                val sendMsg = msgApi.javaClass.methods.first {
                    it.name == "sendMessage" && it.parameterTypes.size == 2 && it.parameterTypes[1] == ByteArray::class.java
                }

                suspend fun postJson(obj: JSONObject) {
                    val data = obj.toString().toByteArray(Charsets.UTF_8)
                    awaitTask<Any?>(sendMsg.invoke(msgApi, nodeId, data))
                }

                val parts = bytes.toList().chunked(CHUNK_SIZE)
                for (targetDir in listOf("prew", "pics")) {
                    readyDeferred = CompletableDeferred()
                    postJson(JSONObject().apply {
                        put("c", "start")
                        put("f", fileName)
                        put("d", targetDir)
                        put("n", parts.size)
                    })
                    val gotReady = withTimeoutOrNull(4000L) { readyDeferred.await() } ?: false
                    log.appendLine("[$targetDir] start -> ready=$gotReady")

                    parts.forEachIndexed { idx, part ->
                        val hex = part.joinToString("") { "%02x".format(it) }
                        postJson(JSONObject().apply {
                            put("c", "d")
                            put("n", idx)
                            put("d", hex)
                        })
                    }
                    postJson(JSONObject().apply { put("c", "end") })
                    log.appendLine("[$targetDir] чанков: ${parts.size}")
                }

                SendResult(true, log.appendLine("Отправка завершена").toString().trim())
            } catch (e: ClassNotFoundException) {
                log.appendLine("Нет com.xiaomi.xms.wearable в app/libs/")
                log.appendLine("Добавь jar с XMS SDK из eBook APK в app/libs/ и пересобери.")
                SendResult(false, log.toString().trim())
            } catch (t: Throwable) {
                Log.e(TAG, "Send error", t)
                log.appendLine("Ошибка: ${t.javaClass.simpleName}: ${t.message}")
                SendResult(false, log.toString().trim())
            }
        }

    private suspend fun <T> awaitTask(task: Any?): T? {
        if (task == null) return null
        val def = CompletableDeferred<T?>()
        val okCls = Class.forName("com.xiaomi.xms.wearable.tasks.OnSuccessListener")
        val failCls = Class.forName("com.xiaomi.xms.wearable.tasks.OnFailureListener")

        val okProxy = Proxy.newProxyInstance(okCls.classLoader, arrayOf(okCls)) { _, m, args ->
            if (m.name == "onSuccess") {
                @Suppress("UNCHECKED_CAST")
                def.complete(args?.firstOrNull() as T?)
            }
            null
        }
        val failProxy = Proxy.newProxyInstance(failCls.classLoader, arrayOf(failCls)) { _, m, args ->
            if (m.name == "onFailure") {
                val err = args?.firstOrNull() as? Throwable ?: RuntimeException("XMS task failed")
                def.completeExceptionally(err)
            }
            null
        }
        task.javaClass.getMethod("addOnSuccessListener", okCls).invoke(task, okProxy)
        task.javaClass.getMethod("addOnFailureListener", failCls).invoke(task, failProxy)
        return def.await()
    }
}
