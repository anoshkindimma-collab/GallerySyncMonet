package com.belugich.band11.picsync

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.min

object ImageProcessor {
    // Экран Mi Band 11: 212x520 px. Держим с запасом под RAM (~16 MB)
    private const val MAX_W = 204
    private const val MAX_H = 360
    private const val MAX_BYTES = 48 * 1024 // 48 KB

    data class ProcessedImage(
        val file: File,
        val fileName: String,
        val width: Int,
        val height: Int,
        val sizeBytes: Int
    )

    fun prepareForBand11(context: Context, sourceUri: Uri): ProcessedImage {
        val rawBytes = context.contentResolver.openInputStream(sourceUri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Не удалось прочитать изображение")

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, bounds)

        var sample = 1
        while (bounds.outWidth / sample > MAX_W * 2 || bounds.outHeight / sample > MAX_H * 2) {
            sample *= 2
        }

        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, decodeOpts)
            ?: throw IllegalStateException("Ошибка декодирования Bitmap")

        val scale = min(
            MAX_W.toFloat() / decoded.width.toFloat(),
            MAX_H.toFloat() / decoded.height.toFloat()
        ).coerceAtMost(1.0f)

        val targetW = (decoded.width * scale).toInt().coerceAtLeast(1)
        val targetH = (decoded.height * scale).toInt().coerceAtLeast(1)

        val scaled = if (targetW != decoded.width || targetH != decoded.height) {
            Bitmap.createScaledBitmap(decoded, targetW, targetH, true).also {
                if (it !== decoded) decoded.recycle()
            }
        } else {
            decoded
        }

        var quality = 85
        var outBytes: ByteArray
        do {
            val baos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, quality, baos)
            outBytes = baos.toByteArray()
            quality -= 10
        } while (outBytes.size > MAX_BYTES && quality >= 35)

        val outDir = File(context.cacheDir, "band11_export").apply { mkdirs() }
        val fileName = "mb11_${System.currentTimeMillis()}.jpg"
        val outFile = File(outDir, fileName)
        FileOutputStream(outFile).use { it.write(outBytes) }

        val w = scaled.width
        val h = scaled.height
        scaled.recycle()

        return ProcessedImage(
            file = outFile,
            fileName = fileName,
            width = w,
            height = h,
            sizeBytes = outBytes.size
        )
    }
}
