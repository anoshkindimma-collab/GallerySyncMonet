package com.belugich.band11.picsync

import android.Manifest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Color(0xFF000000),
                    surface = Color(0xFF121212),
                    primary = Color(0xFFFFFFFF),
                    onPrimary = Color(0xFF000000),
                    onBackground = Color(0xFFFFFFFF),
                    onSurface = Color(0xFFE0E0E0)
                )
            ) {
                PicSyncScreen()
            }
        }
    }
}

@Composable
fun PicSyncScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var infoText by remember { mutableStateOf("Выбери фото для отправки на Mi Band 11") }
    var logText by remember { mutableStateOf("Ожидание действий...") }
    var isBusy by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permLauncher.launch(
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
                )
            )
        }
    }

    val pickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            infoText = "Выбрано: ${uri.lastPathSegment ?: "image"}"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        Text(
            text = "PicSync MB11",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = "Синхронизатор галереи • 212×520",
            fontSize = 14.sp,
            color = Color(0xFF9E9E9E)
        )

        Spacer(Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF141414))
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    text = "Статус",
                    fontSize = 13.sp,
                    color = Color(0xFF888888)
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = infoText,
                    fontSize = 16.sp,
                    color = Color.White
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Button(
            onClick = { pickerLauncher.launch("image/*") },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF222222),
                contentColor = Color.White
            )
        ) {
            Text("1. Выбрать изображение", fontSize = 16.sp)
        }

        Spacer(Modifier.height(12.dp))

        Button(
            enabled = selectedUri != null && !isBusy,
            onClick = {
                val uri = selectedUri ?: return@Button
                scope.launch {
                    isBusy = true
                    infoText = "Сжатие под 212×520 и отправка..."
                    try {
                        val prepared = ImageProcessor.prepareForBand11(context, uri)
                        infoText = "Готово: ${prepared.width}×${prepared.height}, ${prepared.sizeBytes / 1024} KB"
                        val res = WearableBridge.sendPhotoToBand(
                            context = context,
                            imageFile = prepared.file,
                            remoteName = prepared.fileName
                        )
                        logText = res.log
                    } catch (e: Exception) {
                        infoText = "Ошибка подготовки"
                        logText = "${e.javaClass.simpleName}: ${e.message}"
                    } finally {
                        isBusy = false
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color.Black
            )
        ) {
            Text(
                if (isBusy) "Отправка..." else "2. Отправить на Mi Band 11",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(Modifier.height(20.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF101010))
        ) {
            Column(Modifier.padding(14.dp)) {
                Text(
                    text = "Лог диагностики",
                    fontSize = 13.sp,
                    color = Color(0xFF888888)
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = logText,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFFD0D0D0)
                )
            }
        }
    }
}
