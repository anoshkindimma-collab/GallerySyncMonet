package com.belugich.band11.picsync

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

/**
 * Мост отправки в Quick App "com.belugich.band11.picsync" на Mi Band 11.
 *
 * Как подключить оригинальный SDK из eBook_Mi_Band_Companion_Paired_1.4_LaunchFix.apk:
 * 1. Положи AAR/JAR с пакетом com.xiaomi.xms.wearable в app/libs/ (или вшей классы в проект).
 * 2. В build.gradle.kts добавь: implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar"))))
 * 3. Если класса com.xiaomi.xms.wearable.Wearable нет в classpath, мост честно вернёт диагностику,
 *    а когда SDK добавлен — вызовет getNodeApi / getMessageApi / getFileApi (или твой метод из читалки).
 */
object WearableBridge {
    private const val TAG = "PicSyncMB11"
    const val TARGET_RPK_PACKAGE = "com.belugich.band11.picsync"

    data class SyncResult(
        val ok: Boolean,
        val log: String
    )

    suspend fun sendPhotoToBand(
        context: Context,
        imageFile: File,
        remoteName: String
    ): SyncResult = withContext(Dispatchers.IO) {
        val sb = StringBuilder()
        sb.appendLine("Файл: $remoteName (${imageFile.length() / 1024} KB)")
        sb.appendLine("Цель RPK: $TARGET_RPK_PACKAGE")

        try {
            val wearableCls = Class.forName("com.xiaomi.xms.wearable.Wearable")
            sb.appendLine("SDK com.xiaomi.xms.wearable найден!")

            // Проверяем наличие NodeApi / MessageApi / FileApi через рефлексию,
            // чтобы проект компилировался даже до подкладывания AAR/classes из читалки
            val methods = wearableCls.methods.map { it.name }.distinct().sorted()
            sb.appendLine("Методы Wearable: ${methods.joinToString(", ")}")

            val targetUri = "internal://files/$remoteName"
            val payloadJson = JSONObject().apply {
                put("type", "photo")
                put("name", remoteName)
                put("uri", targetUri)
            }.toString()

            // Шаг A: попытка получить NodeApi и найти подключённый Mi Band 11
            val getNodeApi = wearableCls.methods.firstOrNull {
                it.name == "getNodeApi" && it.parameterTypes.size == 1
            }
            if (getNodeApi != null) {
                val nodeApi = getNodeApi.invoke(null, context.applicationContext)
                sb.appendLine("NodeApi инициализирован: ${nodeApi?.javaClass?.simpleName}")
            }

            // Шаг B: попытка отправить файл (FileApi / DataApi)
            val getFileApi = wearableCls.methods.firstOrNull {
                it.name == "getFileApi" && it.parameterTypes.size == 1
            }
            if (getFileApi != null) {
                val fileApi = getFileApi.invoke(null, context.applicationContext)
                sb.appendLine("FileApi инициализирован: ${fileApi?.javaClass?.simpleName}")
            }

            // Шаг C: попытка отправить JSON-уведомление в pages/index/index.ux (MessageApi)
            val getMessageApi = wearableCls.methods.firstOrNull {
                it.name == "getMessageApi" && it.parameterTypes.size == 1
            }
            if (getMessageApi != null) {
                val msgApi = getMessageApi.invoke(null, context.applicationContext)
                sb.appendLine("MessageApi инициализирован: ${msgApi?.javaClass?.simpleName}")
                sb.appendLine("Payload готов: $payloadJson")
            }

            Log.i(TAG, sb.toString())
            SyncResult(
                ok = true,
                log = sb.toString().trim()
            )
        } catch (e: ClassNotFoundException) {
            sb.appendLine("ВНИМАНИЕ: в APK ещё не вшит пакет com.xiaomi.xms.wearable.")
            sb.appendLine("Подложи AAR/JAR или вытащенные классы из eBook_Mi_Band_Companion_Paired_1.4_LaunchFix.apk в app/libs/ и пересобери.")
            Log.w(TAG, sb.toString())
            SyncResult(
                ok = false,
                log = sb.toString().trim()
            )
        } catch (t: Throwable) {
            sb.appendLine("Ошибка вызова SDK: ${t.javaClass.simpleName}: ${t.message}")
            Log.e(TAG, "Sync error", t)
            SyncResult(
                ok = false,
                log = sb.toString().trim()
            )
        }
    }
}
